#include <stdio.h>  

/* This is a comment. */  
int main(int argc, char *argv[])
{
	int times = 100;
	
	// this is also a comment
	printf("Hello World! I welcome you %d times.\n", times);
	
	return 0;
}

