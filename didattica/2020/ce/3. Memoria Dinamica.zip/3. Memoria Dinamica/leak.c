#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool leak(void)
{
	char *s = malloc(4096);
	
	if(s == NULL) {
		return false;
	} else {
		s[0] = 'A';
		return true;
	}
}

int main(void)
{
	while(leak());
	return 0;
}
