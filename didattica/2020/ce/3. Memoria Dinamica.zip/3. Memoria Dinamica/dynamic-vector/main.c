#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#include "vector.h"

#define MAX_STRING 64

typedef struct person {
	char name[MAX_STRING];
	char surname[MAX_STRING];
	unsigned int age;
	unsigned char employed: 1;
	unsigned char married: 1;
	unsigned char has_children: 1;
	unsigned char student: 1;
} person_t;

struct array *people;

static void init_guy(person_t *guy, char *name, char *surname, unsigned int age, bool employed, bool married, bool has_children, bool student)
{
	strncpy(guy->name, name, 64);
	strncpy(guy->surname, surname, 64);
	guy->age = age;
	guy->employed = employed;
	guy->married = married;
	guy->has_children = has_children;
	guy->student = student;
}

static void print_guy(person_t *guy)
{
	assert(guy != NULL);
	printf("%s %s\n", guy->name, guy->surname);
	printf("\tage: %u\n", guy->age);
	printf("\temployed: %s\n", guy->employed ? "yes" : "no");
	printf("\tmarried: %s\n", guy->married ? "yes" : "no");
	printf("\thas children: %s\n", guy->has_children ? "yes" : "no");
	printf("\tstudent: %s\n", guy->student ? "yes" : "no");
}

int main(void)
{
	int i;
	person_t guy;

	people = init_vector(2, sizeof(person_t));

	init_guy(&guy, "Mario",	"Rossi", 48, false, true, true, false);
	push_back(people, &guy);
	init_guy(&guy, "Luigi",	"Esposito", 12, false, false, false, true);
	push_back(people, &guy);
	init_guy(&guy, "Maria",	"Bianchi", 34, true, true, true, false);
	insert_at(people, 0, &guy);
	init_guy(&guy, "Giuseppina", "Romano", 27, false, true, true, false);
	insert_at(people, 1, &guy);
	init_guy(&guy, "Antonio", "Ricci", 76, true, true, false, false);
	push_back(people, &guy);

	for(i = 0; i < 5; i++) {
		if(!extract_from(people, 0, &guy)) {
			printf("Error retrieving person\n");
			continue;
		}
		print_guy(&guy);
	}

	printf("Have records: %s\n", read_from(people, 0, &guy) ? "yes": "no");

	free_vector(people);

	return 0;
}

