#pragma once
#include <stdlib.h>
#include <stdbool.h>

struct array;

extern void *init_vector(size_t nmemb, size_t size);
extern bool insert_at(struct array *arr, size_t pos, void *el);
extern bool push_back(struct array *arr, void *el);
extern bool read_from(struct array *arr, size_t pos, void *buffer);
extern bool extract_from(struct array *arr, size_t pos, void *buffer);
extern void free_vector(struct array *arr);
