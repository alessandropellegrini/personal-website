#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

int somma(int n, ...)
{
	int nSum = 0;

	va_list int_ptr;
	va_start(int_ptr, n);

	for (int i = 0; i < n; i++)
		nSum += va_arg(int_ptr, int);

	va_end(int_ptr);

	return nSum;
}

int main(int argc, char **argv)
{
	printf("10 + 20 = %d\n", somma(2, 10, 20));
	printf("10 + 20 + 30 = %d\n", somma(3, 10, 20, 30));
	printf("10 + 20 + 30 + 40 = %d\n", somma(4, 10, 20, 30, 40));

	return EXIT_SUCCESS;
}
