#include <stdio.h>

typedef enum type
{
	INT,
	FLOAT,
	DOUBLE
} type_t;

typedef union operand
{
	int i;
	float f;
	double d;
} operand_t;

void sum(type_t t, operand_t op1, operand_t op2)
{
	switch(t) {
		case INT:
			printf("%d + %d = %d\n", op1.i, op2.i, op1.i + op2.i);
			break;
		case FLOAT:
			printf("%.02f + %.02f = %.02f\n", op1.f, op2.f, op1.f + op2.f);
			break;
		case DOUBLE:
			printf("%.02lf + %.02lf = %.02lf\n", op1.d, op2.d, op1.d + op2.d);
			break;
		default:
			printf("Unexpected operand types.\n");
	}
}

int main(void)
{
	// Designated union initializers
	operand_t
	    op11 = { .i = 3 },
	    op12 = { .i = 5 },
	    op21 = { .f = 2.18f },
	    op22 = { .f = 8.79f },
	    op31 = { .d = 1.53 },
	    op32 = { .d = 4.71 };

	sum(INT, op11, op12);
	sum(FLOAT, op21, op22);
	sum(DOUBLE, op31, op32);

	printf("\nsizeof(int) = %zu\n", sizeof(int));
	printf("sizeof(float) = %zu\n", sizeof(float));
	printf("sizeof(double) = %zu\n", sizeof(double));
	printf("sizeof(operand_t) = %zu\n", sizeof(operand_t));

	return 0;
}
