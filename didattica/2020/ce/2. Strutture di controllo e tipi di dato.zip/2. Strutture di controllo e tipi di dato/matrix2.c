#include <stdio.h>

int A[2][3] = {{1, 3, 0}, {-1, 5, 9}};
int B[][3] = {{2, 7, -4}, {3, -2, 7}};


void print_matrix1(int row, int col, int M[row][col])
{
	int i, j;

	for(i = 0; i < row; i++) {
		for(j= 0; j < col; j++) {
			printf("%d\t", M[i][j]);
		}
		puts("");
	}
}

void print_matrix2(int col, int M[][col])
{
	int i, j;

	for(i = 0; i < 2; i++) {
		for(j= 0; j < col; j++) {
			printf("%d\t", M[i][j]);
		}
		puts("");
	}
}

int main(int argc, char *argv[])
{
	puts("Matrix A:");
	print_matrix1(2, 3, A);

	puts("\nMatrix B:");
	print_matrix2(3, B);

	return 0;
}
