#include <stdio.h>

int A[2][3] = {{1, 3, 0}, {-1, 5, 9}};
int B[][3] = {{2, 7, -4}, {3, -2, 7}};
int C[2][3] = {0, 0, 0, 0, 0, 0};

void print_matrix(int M[2][3])
{
	int i, j;

	for(i = 0; i < 2; i++) {
		for(j= 0; j < 3; j++) {
			printf("%d\t", M[i][j]);
		}
		puts("");
	}
}

int main(int argc, char *argv[])
{
	int i, j;

	puts("Matrix A:");
	print_matrix(A);

	puts("\nMatrix B:");
	print_matrix(B);

	for(i = 0; i < 2; i++) {
		for(j= 0; j < 3; j++) {
			C[i][j] = A[i][j] + B[i][j];
		}
	}

	puts("\nMatrix C:");
	print_matrix(C);
}
