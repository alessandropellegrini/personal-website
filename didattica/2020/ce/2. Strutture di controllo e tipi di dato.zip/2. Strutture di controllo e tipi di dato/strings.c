#include <stdio.h>

int main(int argc, char *argv[])
{
	int nums[4] = { 0 };
	char name[4] = { 'a', 'p' };

	// first, print them out raw
	printf("nums: %d %d %d %d\n", nums[0], nums[1], nums[2], nums[3]);
	printf("name each: %c %c %c %c\n", name[0], name[1], name[2], name[3]);
	printf("name: %s\n", name);

	// set up the numbers
	nums[0] = 1;
	nums[1] = 2;
	nums[2] = 3;
	nums[3] = 4;

	// set up the name
	name[0] = 'A';
	name[1] = 'l';
	name[2] = 'e';
	name[3] = '\0';

	// then print them out initialized
	printf("nums: %d %d %d %d\n", nums[0], nums[1], nums[2], nums[3]);
	printf("name each: %c %c %c %c\n", name[0], name[1], name[2], name[3]);
	printf("name: %s\n", name);
}
