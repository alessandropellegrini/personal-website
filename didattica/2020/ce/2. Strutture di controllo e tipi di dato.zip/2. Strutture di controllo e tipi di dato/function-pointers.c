#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ELEMENTS 6
int values[] = { 40, 10, 100, 90, 20, 25 };

typedef int (*compare_t)(const void *, const void *);

/**
 * return value	meaning
 * <0		The element pointed to by p1 goes before the element pointed to by p2
 * 0		The element pointed to by p1 is equivalent to the element pointed to by p2
 * >0		The element pointed to by p1 goes after the element pointed to by p2
 */
int compare(const void *a, const void *b)
{
	return (*(int *)a - *(int *)b);
}

void shuffle(int *array, size_t n)
{
	if (n > 1) {
		size_t i;
		for (i = 0; i < n - 1; i++) {
			size_t j = i + rand() / (RAND_MAX / (n - i) + 1);
			int t = array[j];
			array[j] = array[i];
			array[i] = t;
		}
	}
}

void print_array(char *header, int *array, size_t n)
{
	int i;

	printf("%s: ", header);
	for (i = 0; i < n; i++)
		printf("%d ", values[i]);
	puts("");

}

int main(int arcg, char *argv[])
{
	compare_t compare_f1 = compare;
	int (*compare_f2)(const void *, const void *) = compare;

	srand(time(0));

	print_array("Original", values, ELEMENTS);
	qsort(values, ELEMENTS, sizeof(int), compare);
	print_array("Sorted with f.name", values, ELEMENTS);
	shuffle(values, ELEMENTS);
	print_array("Shuffled", values, ELEMENTS);

	qsort(values, ELEMENTS, sizeof(int), compare_f1);
	print_array("Sorted with f.ptr 1", values, ELEMENTS);
	shuffle(values, ELEMENTS);
	print_array("Shuffled", values, ELEMENTS);

	qsort(values, ELEMENTS, sizeof(int), compare_f2);
	print_array("Sorted with f.ptr 2", values, ELEMENTS);

	return 0;
}
