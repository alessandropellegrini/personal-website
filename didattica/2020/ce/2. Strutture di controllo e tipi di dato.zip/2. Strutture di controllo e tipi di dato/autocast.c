#include <stdio.h>

int main(int argc, char *argv[]) {
	double result = 1 / 2 * 2;
	printf("Result is %lf\n", result);
	return 0;
}
