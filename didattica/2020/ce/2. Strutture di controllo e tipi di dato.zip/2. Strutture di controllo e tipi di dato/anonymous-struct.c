#include <stdio.h> 

struct Scope 
{ 
    // Anonymous structure 
    struct
    { 
        char alpha; 
        int num; 
    }; 
}; 
  
int main() 
{ 
    struct Scope x; 
    x.num = 65; 
    x.alpha = 'A'; 
  
    printf("x.alpha = %c, x.num = %d\n", x.alpha, x.num); 
  
    return 0; 
} 
