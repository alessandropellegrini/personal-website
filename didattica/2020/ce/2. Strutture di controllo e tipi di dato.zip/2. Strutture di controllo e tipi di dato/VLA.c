#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void generate_and_print(int n)
{
	int i;
	double vals[n];

	for (i = 0; i < n; i++) {
		vals[i] = (double)rand() / RAND_MAX * 50;
	}

	for (i = 0; i < n; i++)
		printf("%.03f, ", vals[i]);
	printf("\b\b \n");
}

int main(void)
{
	srand(time(NULL));
	generate_and_print(3);
	generate_and_print(1);
	generate_and_print(12);
}
