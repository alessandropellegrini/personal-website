#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_BITS (int)(sizeof(unsigned int) * CHAR_BIT)

char string[MAX_BITS];

char *print_bits(unsigned int value);

int main(int argc, char *argv[]) {
	unsigned int a = 256, sa;
	int b = -256, sb;

	sa = a >> 2;
	sb = b >> 2;
	
	printf("a\t\t= %03d (%s)\n", a, print_bits(a));
	printf("after shift\t= %03d (%s)\n\n", sa, print_bits(sa));
	printf("b\t\t= %04d (%s)\n", b, print_bits(b));
	printf("after shift\t= %04d (%s)\n", sb, print_bits(sb));

	return 0;
}

char *print_bits(unsigned int value)
{
	int i;
	char *p;
	
	p = string + MAX_BITS;
	p[0] = 0;
	
	for(i = 0; i < MAX_BITS; i++) {
	    *--p = value & 1 ? '1' : '0';
	    value >>= 1;
	}
	return string;
}


