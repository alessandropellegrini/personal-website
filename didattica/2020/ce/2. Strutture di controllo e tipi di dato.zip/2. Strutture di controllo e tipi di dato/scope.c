#include <stdio.h>

int main(void)
{
	int number = 5;
	{
		int number = 20;
		printf("inner number: %d\n", number);
        }
	printf("outer number: %d\n", number);

	return 0;
}
