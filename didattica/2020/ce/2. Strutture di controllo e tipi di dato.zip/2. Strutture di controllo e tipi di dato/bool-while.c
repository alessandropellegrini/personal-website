#include <stdio.h>

int main(int argc, char *argv[])
{
	int i = 26;
	do {
		printf("%d, ", --i);
	} while(i);
	printf("\b\b \n");

	i = 0;
	while (i < 26) {
		printf("%d, ", i);
		i++;
	}
	printf("\b\b \n");

	return 0;
}
