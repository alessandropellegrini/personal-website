#include <stdio.h>

int main(int argc, char *argv[])
{
	int nums[] = { 10, 12, 13, 14, 20 };
	char name[] = {'A', 'l', 'e', 's', 's', 'a', 'n', 'd', 'r', 'o', '\0'};
	char *name_ptr = name;

	printf("The size of an int: %ld\n", sizeof(int));
	printf("The size of nums (int[]): %ld\n", sizeof(nums));
	printf("The number of ints in nums: %ld\n\n", sizeof(nums) / sizeof(int));

	printf("The size of a char: %ld\n", sizeof(char));
	printf("The size of name (char[]): %ld\n", sizeof(name));
	printf("The number of chars: %ld\n\n", sizeof(name) / sizeof(char));

	printf("The size of name_ptr: %ld\n", sizeof(name_ptr));
	printf("Bugged number of chars: %ld\n", sizeof(name_ptr) / sizeof(char));

	return 0;
}
