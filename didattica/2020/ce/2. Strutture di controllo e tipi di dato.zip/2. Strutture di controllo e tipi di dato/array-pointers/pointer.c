# include <stdio.h>

extern int *array;

int main(void)
{
	printf("Third element of the array is %d\n" , array[2]);
	return 0;
}
