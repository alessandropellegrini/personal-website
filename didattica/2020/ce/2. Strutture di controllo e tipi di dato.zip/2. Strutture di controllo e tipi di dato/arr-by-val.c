#include <stdio.h>
#include <stdlib.h>

#define SIZE 5

struct wrapper {
	int arr[SIZE];
};

void print(char *msg, int M[SIZE])
{
	int i;
	printf("%s\n", msg);
	for (i = 0; i < SIZE; ++i)
		printf("%d ", M[i]);
	printf("\n");
}

void modify(struct wrapper p)
{
	int i;
	print("\nIn modify(), before changing", p.arr);

	for (i = 0; i < SIZE; ++i)
		p.arr[i] = 100;

	print("\nIn modify(), after changing", p.arr);
}

int main()
{
	int i;
	struct wrapper s;

	for (i = 0; i < SIZE; i++)
		s.arr[i] = 10;
	modify(s);

	print("\nIn main(), after calling modify()", s.arr);
	return 0;
}
