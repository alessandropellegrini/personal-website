#include<stdio.h>
#include<string.h>

#define SIZE 1
#define NUMELEM 5

int main(void)
{
	FILE *fd = NULL;
	char buff[100];
	memset(buff, 0, sizeof(buff));

	if ((fd = fopen("test.txt", "rw+")) == NULL) {
		printf("fopen() error!\n");
		return 1;
	}

	if (fread(buff, SIZE, NUMELEM, fd) != SIZE * NUMELEM) {
		printf("\n fread() failed\n");
		return 1;
	}
	printf("Read [%s] from file\n", buff);

	if (fseek(fd, 11, SEEK_CUR) != 0) {
		printf("\n fseek() failed\n");
		return 1;
	}

	if (fwrite(buff, SIZE, strlen(buff), fd) != SIZE * NUMELEM) {
		printf("\n fwrite() failed\n");
		return 1;
	}

	fclose(fd);

	return 0;
}
