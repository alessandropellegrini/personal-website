#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define Pi M_PI

int main(int argc, char *argv[]) {
    unsigned long int i, inside, tries;
    double x, y;
    double pi;

    tries = atoi(argv[1]);

    /* Metodo MONTECARLO */
    srand48(tries);

    inside=0;
    for (i = 0; i < tries; i++) {
      x = drand48();
      y = drand48();
      if( x*x + y*y < 1.0 )
		  inside++;
    }

    pi = 4.0 * inside / (double)tries;

    printf("\nReal Pi value: %.16f\n",Pi);
    printf(  "Pi estimate  : %.16f\n",pi);
    printf(  "Error        : %.16f\n", pi-Pi);

    return 0;
}
