#pragma once
#include <stdint.h>

typedef uint64_t seed_type;

extern double Random(void);
extern double Expent(double mean);
