char c;
char v[1024];

void instring(char *s){
	int i = 0;

	do {
		#ifndef m32
		asm volatile("mov %%rbx, %%rdi\n"
			     "mov %%rcx, %%rsi\n"
			     "syscall"
			     :
			     : "a" (0), "b" (0), "c" ((unsigned long)(&c)), "d" ((long)(1))
			    );
		#else
		asm volatile("int $0x80"
			     :
			     : "a" (3), "b" (0), "c" ((unsigned long)(&c)), "d" ((long)(1))
			    ); 
		#endif

	     	s[i] = c;
		i++; 
 	} while ( (c!='\n') && (c != ' ') && (c != '\t'));

       	i--;
	s[i]='\0';
}

void outstring(char *s){
	int i = 0;
	while (s[i++] != '\0');

	i--;

	#ifndef m32
	asm volatile("mov %%rbx, %%rdi\n"
		     "mov %%rcx, %%rsi\n"
		     "mov %%rdx, %%rdx\n"
		     "syscall"
		     :
		     : "a" (1), "b" (1), "c" ((unsigned long)(s)), "d" ((long)(i))
		    );
	#else
	asm volatile("int $0x80"
		     :
		     : "a" (4), "b" (1), "c" ((unsigned long)(s)), "d" ((long)(i))
		    );
	#endif
}


int _start(int argc) {
	while(1){
		instring(v);
		outstring(v);
		outstring("\n");
	}
}
