#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>

long long shared_variable;

bool CAS(volatile unsigned long long *ptr, unsigned long long oldVal, unsigned long long newVal) {
	unsigned long res = 0;

	__asm__ __volatile__(
		"lock cmpxchgq %1, %2;"//ZF = 1 if succeeded
		"lahf;"  // to get the correct result even if oldVal == 0
		"bt $14, %%ax;" // is ZF set? (ZF is the 6'th bit in %ah, so it's the 14'th in ax)
		"adc %0, %0" // get the result
		: "=r"(res)
		: "r"(newVal), "m"(*ptr), "a"(oldVal), "0"(res)
		: "memory"
	);

	return (bool)res;
}


void *competing(void *ptr) {
	long long me = (long long)ptr;
	int old_value;

	while(true) {
		old_value = shared_variable;
		if(CAS(&shared_variable, old_value, me)) {
			printf("Update by %lld\n", me);
		}
	}

	return NULL;
}


int main(int argc, char **argv) {
	pthread_t tid;
	int n_th;
	long long i;
	
	if(argc < 2) {
		printf("Usage: %s <num_threads>\n", argv[0]);
		exit(EXIT_SUCCESS);
	}

	n_th = atoi(argv[1]);

	for(i = 0; i < n_th; i++) {
		if(pthread_create(&tid, NULL, competing, (void *)i) != 0) {
			fprintf(stderr, "Unable to spawn a new thread\n");
			exit(EXIT_FAILURE);
		}
	}

	competing((void *)i);
}
