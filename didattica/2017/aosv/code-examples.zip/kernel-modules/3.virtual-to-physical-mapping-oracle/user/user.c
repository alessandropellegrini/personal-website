#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

unsigned int __NR_vtpmo;

int vtpmo(void *addr) {
	return syscall(__NR_vtpmo, addr);
}

#define NUM_TARGET_PAGES 10
char buff[4096*NUM_TARGET_PAGES];


int main(int argc, char** argv) {
	int frame_num;
	int i;
	char c;
	int op;
	
	if(argc < 3) {
		fprintf(stderr, "Usage %s __NR_vtpmo operation\n", argv[0]);
		fprintf(stderr, "\toperation: 1 = read, 2 = write, 3 = vtpmo, 4 = stack, 5 = NULL\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	__NR_vtpmo = atoi(argv[1]);
	op = atoi(argv[2]);
	        
	buff[0] = 'p';

	printf("Asking for address %p\n", buff);
	fflush(stdout);
	frame_num = vtpmo(buff);
	printf("Address %p mapped to frame %d\n", buff, frame_num);

	frame_num = vtpmo(buff + 1);
	printf("Address %p mapped to frame %d\n", buff + 1, frame_num);
	
	switch(op) {
		case 1:

			for(i = 0; i < NUM_TARGET_PAGES; i++) {
				c = buff[i * 4096];
				frame_num = vtpmo(buff + (i * 4096));
				printf("address %p mapped to frame %d\n",(buff + (i * 4096)), frame_num);
			}
			break;
			
		case 2:
			for(i = 0; i < NUM_TARGET_PAGES; i++) {
				buff[i * 4096] = 'p' ;
				frame_num = vtpmo(buff + (i * 4096));
				printf("address %p mapped to frame %d\n",(buff+(i*4096)),frame_num);
			}
			break;
			
			
		case 3:
			for(i = 0; i < NUM_TARGET_PAGES; i++) {
				frame_num = vtpmo(buff + (i * 4096));
				printf("address %p mapped to frame %d\n",(buff + (i * 4096)),frame_num);
			}
			break;
			
		case 4:
			frame_num = vtpmo(&frame_num);
			printf("address %p mapped to frame %d\n", &frame_num, frame_num);
			break;
			
		case 5:
			frame_num = vtpmo(NULL);
			printf("address %p mapped to frame %d\n", NULL, frame_num);
			break;
 
		default:
			fprintf(stderr, "Unrecognized operation\n");
	}

	return 0;
}

