#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/errno.h>
#include <linux/device.h>
#include <linux/kprobes.h>
#include <linux/mutex.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/kprobes.h>
#include <linux/syscalls.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Alessandro Pellegirni <pellegrini@diag.uniroma1.it>");
MODULE_AUTHOR("Francesco Quaglia <qfrancesco.quaglia@uniroma2.it>");
MODULE_DESCRIPTION("Virtual-to-physical Page Mapping Oracle");


#define PML4(addr) (((long long)(addr) >> 39) & 0x1ff)
#define PDP(addr)  (((long long)(addr) >> 30) & 0x1ff)
#define PDE(addr)  (((long long)(addr) >> 21) & 0x1ff)
#define PTE(addr)  (((long long)(addr) >> 12) & 0x1ff)

#define NO_MAP -1
#define LARGE_PAGE_MAP 0

extern unsigned long __force_order;

static unsigned long cr0;
static unsigned long *__sys_call_table;
static unsigned long __sys_ni_syscall;
static unsigned int syscall_entry;


unsigned long *get_syscall_table_bf(void)
{
	unsigned long *syscall_table;
	unsigned long int i;

	for (i = (unsigned long int)sys_close; i < ULONG_MAX; i += sizeof(void *)) {
		syscall_table = (unsigned long *)i;

		if (syscall_table[__NR_close] == (unsigned long)sys_close)
			return syscall_table;
	}
	return NULL;
}


static inline void protect_memory(void)
{
	write_cr0(cr0);
}


static inline void unprotect_memory(void)
{
	write_cr0(cr0 & ~0x00010000);
}


static inline unsigned long read_cr3(void)
{
	unsigned long val = 0;
	asm volatile("mov %%cr3,%0\n\t" : "=r" (val), "=m" (__force_order));
	return val;
}


asmlinkage int sys_vtpmo(unsigned long long addr) {
	void** pdp;
	void** pde;
	void** pte;
	void** pml4;
	int frame_number;
	unsigned long long frame_addr;
	
	unsigned long long target_address = addr;
	
	printk("%s: Virtual-to-Physical translation of virtual address 0x%llx\n", KBUILD_MODNAME, target_address);
	
	pml4  = (void **)__va(read_cr3() & 0xfffffffffffff000);
	printk("%s: Accessing PML4 entry number %lld\n", KBUILD_MODNAME, PML4(target_address));

	if( !((unsigned long long)pml4[PML4(target_address)] & 0x1) ) {
		printk("%s: PML4 entry not mapped to physical memory\n", KBUILD_MODNAME);
		return NO_MAP;
	} 

	pdp = __va((unsigned long long)pml4[PML4(target_address)] & 0xffffffffffff000);
	printk("%s: Accessing PDP entry number %lld\n", KBUILD_MODNAME, PDP(target_address));

	if( !((unsigned long long)pdp[PDP(target_address)] & 0x1) ) {
		printk("%s: PDP entry not mapped to physical memory\n", KBUILD_MODNAME);
		return NO_MAP;
	}

	pde = __va((unsigned long long)pdp[PDP(target_address)] & 0xffffffffffff000);              
	printk("%s: Accessing PDE entry number %lld\n", KBUILD_MODNAME, PDE(target_address));

	if( !((unsigned long long)pde[PDE(target_address)] & 0x1) ){ 
		printk("%s: PDE entry not mapped to physical memory\n",KBUILD_MODNAME);
		return NO_MAP;
	}

	if((unsigned long long)pde[PDE(target_address)] & 0x080){ 
		printk("%s: PDE entry mapped to a huge page\n",KBUILD_MODNAME);
		return LARGE_PAGE_MAP;
	}

	pte = __va((unsigned long long)pde[PDE(target_address)] & 0xffffffffffff000);              
	printk("%s: Accessing PTE entry number %lld\n",KBUILD_MODNAME,PTE(target_address));

	if( !((ulong)pte[PTE(target_address)] & 0x1) ){
		
		printk("%s: PTE entry not mapped to physical memory\n",KBUILD_MODNAME);
		return NO_MAP;
	}

	frame_addr = (unsigned long long)pte[PTE(target_address)] & 0x7ffffffffffff000; 
	printk("%s: Page Frame address is 0x%llx\n", KBUILD_MODNAME, frame_addr);

	frame_number = frame_addr >> 12;
	return frame_number;
}


static int __init setup(void)
{
	struct kprobe kp;
	
	__sys_call_table = get_syscall_table_bf();
	if (!__sys_call_table)
		return -1;

	cr0 = read_cr0();
	
	memset(&kp, 0, sizeof(kp));
	kp.symbol_name = "sys_ni_syscall";
	if (!register_kprobe(&kp)) {
		__sys_ni_syscall = (unsigned long)kp.addr;
		printk(KERN_INFO "%s: found sys_ni_syscall at %pK\n", KBUILD_MODNAME, (void *)__sys_ni_syscall);
		unregister_kprobe(&kp);
	} else {
		return -2;
	}
	
	for(syscall_entry = 0;; syscall_entry++) {
		if(__sys_call_table[syscall_entry] == __sys_ni_syscall) {
			unprotect_memory();
			__sys_call_table[syscall_entry] = (unsigned long)sys_vtpmo;
			protect_memory();
			printk(KERN_INFO "%s: Installed the vtpmo at entry %d\n", KBUILD_MODNAME, syscall_entry);
			break;
		}
		
		if(syscall_entry > 500) {
			printk(KERN_INFO "%s: Did not find a suitable entry for sys_vtpmo\n", KBUILD_MODNAME);
			break;
		}
	}
	
	return 0;
}


static void __exit shutdown(void)
{
	unprotect_memory();
    __sys_call_table[syscall_entry] = __sys_ni_syscall;
    protect_memory();    
}


module_init(setup);
module_exit(shutdown);
