#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/ktime.h>
#include <linux/limits.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/printk.h>

#include "hook.h"

static unsigned long old_hook = 0;

unsigned long hook_func = 0;
module_param(hook_func, ulong, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);

unsigned long audit_counter = 0;
module_param(audit_counter, ulong, S_IRUSR | S_IRGRP | S_IROTH);

static int sample_counter = 0;

MODULE_AUTHOR("Stefano Carnà <stefano.carna.dev@gmail.com>");
MODULE_AUTHOR("Alessandro Pellegrini <pellegrini@diag.uniroma1.it>");
MODULE_DESCRIPTION("This module will execute a specified function"
		   "just after the task switch completion");
MODULE_LICENSE("GPL");

/*
 * Post-execution function hanlder: this perfoms the function whose address
 * is contained in the hook_func variable.
 */
static int post_handler(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	h_func *hook;
	audit_counter ++;

	if (hook_func != old_hook) {
		old_hook = hook_func;
		if(!hook_func) {
			pr_info("%s: hook function disabled\n", KBUILD_MODNAME);
		} else {
			pr_info("%s: new hook function installed at %llx\n", KBUILD_MODNAME, (unsigned long long)hook_func);
		}
	}

	if (!hook_func) goto end;

	hook = (h_func*) hook_func;
	hook();

end:
	return 0;
}

static struct kretprobe krp = {
	.handler                = post_handler
};


void sample_hook(void) 
{
	sample_counter++;
	if(sample_counter % 1000 == 0) {
		pr_info("%s: task with pid %d is about to be scheduled\n", KBUILD_MODNAME, current->pid);
	}
}


static int __init hook_init(void)
{
	int ret;

	krp.kp.symbol_name = switch_func;
	ret = register_kretprobe(&krp);
	if (ret < 0) {
		pr_info("hook init failed, returned %d\n", ret);
		return ret;
	}
	pr_info("%s: hook module correctly loaded. Sample function is at 0x%llx\n", KBUILD_MODNAME, (unsigned long long)sample_hook);

	return 0;
}

static void __exit hook_exit(void)
{
	unregister_kretprobe(&krp);

	pr_info("%s: Hook invoked %lu times\n", KBUILD_MODNAME, audit_counter);
	if (krp.nmissed) pr_info("%s: Missed %u invocations\n", KBUILD_MODNAME, krp.nmissed);

	pr_info("%s: hook module unloaded\n", KBUILD_MODNAME);
}

module_init(hook_init)
module_exit(hook_exit)
