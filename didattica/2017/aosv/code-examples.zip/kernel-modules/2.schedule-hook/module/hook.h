#pragma once

#define switch_func "finish_task_switch"

typedef void h_func(void);