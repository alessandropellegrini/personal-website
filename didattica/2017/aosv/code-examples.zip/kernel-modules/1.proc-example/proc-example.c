#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>


MODULE_LICENSE("GPL"); 
MODULE_AUTHOR("Francesco Quaglia <francesco.quaglia@uniroma2.it>");
MODULE_AUTHOR("Alessandro Pellegrini <pellegrini@diag.uniroma1.it>");
MODULE_VERSION("1.1");

static char *content = NULL;
module_param(content, charp, 0000);
MODULE_PARM_DESC(content, "The content of the proc file");

static struct proc_dir_entry *my_entry;

ssize_t read_proc(struct file *filp, __user char *buf, size_t count, loff_t *offp);

struct file_operations proc_fops = {
	read: read_proc
};


ssize_t read_proc(struct file *filp, __user char *buf, size_t count, loff_t *offp) 
{
	int len = strlen(content);
	if(*offp >= len)
		return 0;

	len = len - *offp;
	if(count > len) {
		count = len;
	}
	
	copy_to_user(buf, content + *offp, count);
	*offp += count;

	return count;
}

int proc_init(void)
{
	if(content == NULL) {
		printk(KERN_ERR "%s: Unable to create the proc file: no content specified\n", KBUILD_MODNAME);
		return -EBADMSG;
	}
	
	my_entry = proc_create("hello", 0, NULL, &proc_fops);
	printk(KERN_INFO "%s: Created a proc file 'hello' with %lu bytes content for string %s\n", KBUILD_MODNAME, strlen(content), content);
	
	return 0;
}

void proc_cleanup(void) {
	remove_proc_entry("hello", NULL);
}


module_init(proc_init);
module_exit(proc_cleanup);
