#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stropts.h>

#include "address_space_hit.h"

long activations;
int fd = -1;
long val = 123;

int main(int argc, char** argv){
	
	if((fd = open("/dev/address_space_hit", O_RDONLY)) == -1) {
		perror("Error opening special device file");
		exit(EXIT_FAILURE);
	}
	
	printf("I'm process %d - target addr is: %p\n", getpid(), &val);

	while(1){
		sleep(3);
		ioctl(fd, IOCTL_HIT_ACTIVATIONS, &activations);
		printf("value id: %ld (module activated %ld times)\n", val, activations);
	}
}
