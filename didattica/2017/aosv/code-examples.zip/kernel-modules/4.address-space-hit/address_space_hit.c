#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/sched.h>	
#include <linux/pid.h>
#include <linux/tty.h>
#include <linux/version.h>
#include <linux/tlbflush.h>

#include "address_space_hit.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Alessandro Pellegrini <pellegrini@dis.uniroma1.it>");
MODULE_AUTHOR("Francesco Quaglia <francesco.quaglia@uniroma2.it>");

#define LINE_SIZE 128

static int hit_open(struct inode *, struct file *);
static int hit_release(struct inode *, struct file *);
static ssize_t hit_write(struct file *, const char *, size_t, loff_t *);
static long hit_ioctl(struct file *, unsigned int, unsigned long);

static struct file_operations fops = {
	.write = hit_write,
	.open =  hit_open,
	.release = hit_release,
	unlocked_ioctl: hit_ioctl,
	compat_ioctl: hit_ioctl, // Nothing strange is passed, so 32 bits programs should work out of the box. Never tested, yet.
};

static int major;
static struct class *dev_cl = NULL;
static struct device *device = NULL;
static long activations = 0;

static inline unsigned long read_cr3(void)
{
	unsigned long val = 0;
	asm volatile("mov %%cr3,%0\n\t" : "=r" (val), "=m" (__force_order));
	return val;
}


static int hit_open(struct inode *inode, struct file *file)
{
	// Nothing special to do
	return 0;
}

static int hit_release(struct inode *inode, struct file *file)
{
	// Nothing special to do
	return 0;
}

static ssize_t hit_write(struct file *filp, const char *buff, size_t len, loff_t *off)
{
	char buffer[LINE_SIZE];
	long pid;
	unsigned long long addr;
	long val;
	int format = 0;
	int i,j;
	int ret;

	char *args[3];

	struct task_struct *the_task;
	void *restore_pml4;
	unsigned long restore_cr3;

	printk(KERN_INFO "%s: Writing on broadcast dev with <major, minor> number = <%d, %d>\n", KBUILD_MODNAME, MAJOR(filp->f_inode->i_rdev), MINOR(filp->f_inode->i_rdev));
 
	if(len >= LINE_SIZE)
		return -1;
	ret = copy_from_user(buffer, buff, len);

	j = 1;
	for(i=0;i<len;i++){
		if(buffer[i] == ' ') {
			buffer[i] = '\0';
			args[j++] = buffer + i + 1;
			format++;
		}
	}

	if(format != 2)
		return -1;

	args[0] = buffer;

	buffer[len] = '\0';
	ret = kstrtol(args[0], 10, &pid);
	ret = kstrtoll(args[1], 16, &addr);
	ret = kstrtol(args[2], 10, &val);

	printk(KERN_INFO "%s: args are: %ld - 0x%llx - %ld\n", KBUILD_MODNAME, pid, addr, val);

	the_task = pid_task(find_vpid(pid), PIDTYPE_PID);

	if(!the_task)
		return -1;

	restore_pml4 = current->mm->pgd;
	restore_cr3 = read_cr3();

	if(!(the_task->mm))
		return -1; 
	if(!(the_task->mm->pgd))
		return -1; 

	printk(KERN_INFO "%s: found process %ld with a valid memory map\n", KBUILD_MODNAME, pid);

	current->mm->pgd = the_task->mm->pgd;
	write_cr3(__pa(the_task->mm->pgd));
	flush_tlb_all();

	// do the hack
	printk(KERN_INFO "%s: value at 0x%llx is %ld\n", KBUILD_MODNAME, addr, *(long *)addr);
	ret = copy_to_user((void*)addr, (void*)&val, sizeof(val));
	printk(KERN_INFO "%s: copied to used with return value %d\n", KBUILD_MODNAME, ret);
	printk(KERN_INFO "%s: value at 0x%lx is %ld\n", KBUILD_MODNAME, addr, *(long *)addr);

	// get back on my mm
	current->mm->pgd = restore_pml4;
	write_cr3(restore_cr3);
	
	activations++;
	return len;
}

static long hit_ioctl(struct file *filp, unsigned int cmd, unsigned long ptr)
{
	long __user *uptr = (long *)ptr;
	long ret;
	
	switch (cmd) {

		case IOCTL_HIT_ACTIVATIONS:
			ret = copy_to_user(uptr, &activations, sizeof(long));
			break;
			
		default:
			ret = -1;
	}
	
	return ret;
}

// Standard constructor: cannot be static
int __init init_module(void)
{
	int ret;
	major = register_chrdev(0, KBUILD_MODNAME, &fops);

	// Dynamically allocate a major for the device
	if (major < 0) {
		printk(KERN_ERR "%s: Failed registering char device\n", KBUILD_MODNAME);
		ret = major;
		goto failed_chrdevreg;
	}
	
	// Create a class for the device
	dev_cl = class_create(THIS_MODULE, "rootsim");
	if (IS_ERR(dev_cl)) {
		printk(KERN_ERR "%s: failed to register device class\n", KBUILD_MODNAME);
		ret = PTR_ERR(dev_cl);
		goto failed_classreg;
	}
	
	// Create a device in the previously created class
	device = device_create(dev_cl, NULL, MKDEV(major, 0), NULL, KBUILD_MODNAME);
	if (IS_ERR(device)) {
		printk(KERN_ERR "%s: failed to create device\n", KBUILD_MODNAME);
		ret = PTR_ERR(device);
		goto failed_devreg;
	}

	printk(KERN_INFO "%s: hit device registered, it is assigned major number %d\n", KBUILD_MODNAME, major);
	return 0;
	
  failed_devreg:
	class_unregister(dev_cl);
	class_destroy(dev_cl);
  failed_classreg:
	unregister_chrdev(major, KBUILD_MODNAME);
  failed_chrdevreg:
	return ret;
}

// Standard destructor: cannot be static
void __exit cleanup_module(void)
{
	device_destroy(dev_cl, MKDEV(major, 0));
	class_unregister(dev_cl);
	class_destroy(dev_cl);
	unregister_chrdev(major, KBUILD_MODNAME);

	printk(KERN_INFO "%s: hit device unregistered, it was assigned major number %d\n", KBUILD_MODNAME, major);
}

