#pragma once

//#ifdef HAVE_CROSS_STATE

#include <linux/ioctl.h>

#define IOCTL_MAGIC 'H'

#define IOCTL_HIT_ACTIVATIONS _IOR(IOCTL_MAGIC, 1, long)
