#include <unistd.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <stdio.h>
#include <string.h>

#define SIZE 4096*4096

int main(void) {
	char *ptr = NULL;
	int i = 0;
	
	while(true) {
		ptr = mmap(ptr, SIZE, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, 0, 0);
		
	//	memset(ptr, 'x', SIZE);
		
		usleep(1000);

		if(++i % 100 == 0) {
			printf("mmapped %f MBs\n", i * (double)SIZE / 1024 / 1024);
		}
	}
}
