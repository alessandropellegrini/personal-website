#!/bin/bash
 
./bof $(python2 -c "print 'A' * $1")
