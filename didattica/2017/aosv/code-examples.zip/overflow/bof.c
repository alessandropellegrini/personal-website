#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
	char buffer[100];
	
	printf("buf at %p\n", buffer);
	
	strcpy(buffer, argv[1]);
	printf("Input was: %s\n", buffer);
	
	//printf("returning to %p\n", __builtin_return_address(0));
	//printf("byte there: %#02x\n", *((char *)__builtin_return_address(0)));

	return 0;
}
