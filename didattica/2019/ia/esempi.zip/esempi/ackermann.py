#!/usr/bin/env python3

import sys

def ackermann(m,n):
    # Ackermann function
    if m == 0:
        return n+1
    elif m > 0 and n == 0:
        return ackermann(m-1,1)
    else:
        return ackermann(m-1,ackermann(m,n-1))

sys.setrecursionlimit(100000)

print(ackermann(int(sys.argv[1]), int(sys.argv[2])))
