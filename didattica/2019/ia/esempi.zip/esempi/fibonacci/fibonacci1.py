#!/usr/bin/env python3

import math
import sys

phy = 1.618

def fibonacci1(n):
      return 1/math.sqrt(5) * (math.pow(phy, n) - math.pow(-phy, -n))

print(fibonacci1(int(sys.argv[1])))
