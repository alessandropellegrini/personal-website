#!/usr/bin/env python3

import math
import sys

def fibonacci3(n):
    Fib = [0] * n
    Fib[0] = 1
    Fib[1] = 1

    for i in range(2, n):
        Fib[i] = Fib[i-1] + Fib[i-2]
    return Fib[n-1]


print(fibonacci3(int(sys.argv[1])))
