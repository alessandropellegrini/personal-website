#!/usr/bin/env python3

import math
import sys

def fibonacci4(n):
    F0 = 1
    F1 = 1
    F2 = 1

    for i in range(2, n):
        F0 = F1
        F1 = F2
        F2 = F0 + F1
    return F2


print(fibonacci4(int(sys.argv[1])))
