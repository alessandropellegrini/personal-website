#!/usr/bin/env python3

# Riconoscitore di stringhe parenteticamente corrette

class simpleStack:
    def __init__(self):
        self.stack = []
        self.size = 0

    def push(self, el):
        self.stack.append(el)
        self.size += 1

    def pop(self):
        if(self.size == 0):
            return None
        self.size -= 1
        return self.stack.pop()

    def isEmpty(self):
        return self.size == 0

# Come modificare questa funzione per riconoscere più tipi di parentesi?
# es: 
#  - fg{([{ab(vc)g}kj])} è corretta
#  - gh{(df[ghj]}gh)hj non è corretta

def stringAnalyzer(s):
    stack = simpleStack()
    balanced = True

    for c in s:
        if c == ')':
            if stack.isEmpty():
                balanced = False
            else:
                stack.pop()

        if c == '(':
            stack.push('(')

    if not stack.isEmpty():
        balanced = False

    return balanced

print("ab(ax)((b)du(mb)) è corretta?", stringAnalyzer("ab(ax)((b)du(mb))"))
print("a(ax)(c è corretta?", stringAnalyzer("a(ax)(c"))
print("a)b(e è corretta?", stringAnalyzer("a)b(e"))



