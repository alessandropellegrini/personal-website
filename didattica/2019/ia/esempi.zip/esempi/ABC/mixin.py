#!/usr/bin/env python3

import logging

class LoggerMixin(object):
    @property
    def logger(self):
        name = '.'.join([
            self.__module__,
            self.__class__.__name__
        ])
        return logging.getLogger(name)


class Object1(LoggerMixin, object):
    def __init__(self):
        super().__init__()
        self.logger.error('Object 1 has been initialized')

class Object2(LoggerMixin, object):
    def __init__(self):
        super().__init__()
        self.logger.error('Object 2 has been initialized')

o1 = Object1()
o2 = Object2()
