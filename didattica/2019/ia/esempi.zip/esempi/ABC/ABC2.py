#!/usr/bin/env python3

import abc

class Uccello(abc.ABC):
    @abc.abstractmethod
    def vola(self):
        pass

class Pappagallo(Uccello):
    def vola(self):
        print("Sto volando!")

p = Pappagallo()
