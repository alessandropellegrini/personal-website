#!/usr/bin/env python3

import abc

class Uccello(abc.ABC):
    @abc.abstractmethod
    def vola(self):
        pass

class Aeroplano(abc.ABC):
    @abc.abstractmethod
    def vola(self):
        pass

class Pappagallo(Uccello):
    def vola(self):
        print("Sto volando!")

class Boeing(Aeroplano):
    def vola(self):
        print("Sto volando!")

p = Pappagallo()
b = Boeing()

print("Il pappagallo è un aeroplano?", isinstance(p, Aeroplano))
print("Il Boeing è un uccello?", isinstance(b, Uccello))
