#!/usr/bin/env python3

from myVector import MyVector

v1 = MyVector(10, 10)
print(v1.x, v1.y)

v2 = v1 * 4
print(v2.x, v2.y)

v3 = v1._rotate2D(10)
print(v3.x, v3.y)

prod = v1.inner(v2)
print(prod)

mat = [[1,2,3],[-1,0,1],[3,4,5]]
v5 = MyVector(1,2,3).matrix_mult(mat)
print(v5.x, v5.y, v5.z)
