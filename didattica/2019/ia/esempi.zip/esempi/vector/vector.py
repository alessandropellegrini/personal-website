#!/usr/bin/env python3

import abc

class Vector(abc.ABC):
    @abc.abstractmethod
    def norm(self):
        pass

    @abc.abstractmethod
    def argument(self):
        pass

    @abc.abstractmethod
    def normalize(self):
        pass

    @abc.abstractmethod
    def rotate(self, *args):
        pass

    @abc.abstractmethod
    def _rotate2D(self, theta):
        pass

    @abc.abstractmethod
    def matrix_mult(self, matrix):
        pass

    @abc.abstractmethod
    def inner(self, other):
        pass


