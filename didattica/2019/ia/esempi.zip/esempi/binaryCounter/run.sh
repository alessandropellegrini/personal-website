#!/bin/bash
for i in {1..16}; do
	time=$(/usr/bin/time -f "%e" ./binaryCounter.py $((2 ** $i)) 2>&1)
	echo -e "$((2 ** $i))\t$time"
	>&2 echo -e "$((2 ** $i))\t$time"
done
