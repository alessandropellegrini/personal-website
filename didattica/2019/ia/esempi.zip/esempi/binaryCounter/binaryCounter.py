#!/usr/bin/env python3

import sys

A = [0] * 16

def increment(A, k):
    i = 0
    while i < k and A[i] == 1:
        A[i] = 0
        i = i + 1
    if i < k:
        A[i] = 1
    return A

for i in range(0, int(sys.argv[1])):
    A = increment(A, len(A))

print(A)
