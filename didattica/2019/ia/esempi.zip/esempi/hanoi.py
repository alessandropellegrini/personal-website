#!/usr/bin/env python3

import sys

steps=0

def moveTower(n, source, dest, temp):
    global steps
    if n == 1:
        print("Move disk from", source, "to", dest)
        steps = steps + 1
    else:
        print("Chiamata 1 per n =", n)
        moveTower(n - 1, source, temp, dest)
        print("Chiamata 2 per n =", n)
        moveTower(1, source, dest, temp)
        print("Chiamata 3 per n =", n)
        moveTower(n - 1, temp, dest, source)

def hanoi(n):
    moveTower(n, "A", "C", "B")

hanoi(int(sys.argv[1]))
print(steps, "steps required")
