import ctypes 
from collections.abc import Collection

class DynamicArray(Collection): 
		''' 
		DYNAMIC ARRAY CLASS 
		'''
		
		def __init__(self): 
				self.n = 0 # Count actual elements (Default is 0) 
				self.capacity = 1 # Default Capacity 
				self.A = self._make_array(self.capacity) 
				self.count = 0
				
		def __len__(self): 
				""" 
				Return number of elements stored in array 
				"""
				return self.n 

		def __contains__(self, item): 
				return item in self.A

		def __iter__(self):
				self.count = 0
				return self

		def __next__(self):
				if self.count >= self.n:
					raise StopIteration
				else:
					self.count += 1
					return self[self.count - 1]

		def __getitem__(self, k): 
				""" 
				Return element at index k 
				"""
				if not 0 <= k <self.n: 
						# Check it k index is in bounds of array 
						raise IndexError('Index ' + str(k) + ' is out of bounds !') 
				
				return self.A[k] # Retrieve from the array at index k 
				
		def append(self, ele): 
				""" 
				Add element to end of the array 
				"""
				if self.n == self.capacity: 
						# Double capacity if not enough room 
						self._resize(2 * self.capacity) 
				
				self.A[self.n] = ele # Set self.n index to element 
				self.n += 1
				
		def _resize(self, new_cap): 
				""" 
				Resize internal array to capacity new_cap 
				"""
				
				B = self._make_array(new_cap) # New bigger array 
				
				for k in range(self.n): # Reference all existing values 
						B[k] = self.A[k] 
						
				self.A = B # Call A the new bigger array 
				self.capacity = new_cap # Reset the capacity 
				
		def _make_array(self, new_cap): 
				""" 
				Returns a new array with new_cap capacity 
				"""
				return (new_cap * ctypes.py_object)() 

