from collections.abc import MutableSequence
from ListNode import ListNode

class DoublyLinkedList(MutableSequence):
        def __init__(self):
            self.head = ListNode(None)
            self.tail = ListNode(None)
            self.head.next = self.tail
            self.tail.prev = self.head
            self.size = 0

        def insert_between(self, node, predecessor, successor):
            node.next = successor
            node.prev = predecessor
            predecessor.next = node
            successor.prev = node
            self.size += 1

        def insert(self, index, element):
            node = ListNode(element)
            successor = self._getitem(index)
            predecessor = successor.prev
            self.insert_between(node, predecessor, successor)

        def append(self, element):
            node = ListNode(element)
            successor = self.tail
            predecessor = successor.prev
            self.insert_between(node, predecessor, successor)

        def appendLeft(self, element):
            node = ListNode(element)
            predecessor = self.head
            successor = predecessor.next
            self.insert_between(node, predecessor, successor)

        def __reversed__(self):
            current_node = self.tail.prev
            while current_node is not self.head:
                yield current_node.data
                current_node = current_node.prev

        def _getitem(self, index):
            count = 0
            current_node = self.head.next
            while current_node is not self.tail and count < index:
                current_node = current_node.next
                count += 1

            if current_node is None and count != index:
                return None
            return current_node

        def __getitem__(self, index):
            node = self._getitem(index)
            if node is None:
                print('No element at index', index)
                raise IndexError('No element at index', index)
            return self._getitem(index).data

        def __setitem__(self, index, value):
            node = self._getitem(index)
            node.data = value

        def __delitem__(self, index):
            node = self._getitem(index)
            predecessor = node.prev
            successor = node.next
            predecessor.next = successor
            successor.prev = predecessor
            self.size -= 1
            node.prev = node.next = None
            return node.data

        def __len__(self):
            return self.size

        def __str__(self):
            current_node = self.head.next
            dump = "["
                
            while current_node is not self.tail:
                dump += str(current_node) + ","
                current_node = current_node.next

            dump += "]"
            return dump
