#!/usr/bin/env python3

from LinkedList import SinglyLinkedList

print("Instantiating a Singly Linked List")
ll = SinglyLinkedList()
print(ll)

print("Adding an element to tail")
ll.append(10)
print(ll)

print("Adding an element to head")
ll.appendLeft(1)
print(ll)

print("Inserting an element at index 0")
ll.insert(0, 0)
print(ll)

print("Inserting an element at index 2")
ll.insert(2, 2)
print(ll)

print("Inserting an element at index 4")
ll.insert(4, 20)
print(ll)

print("Iterating over list")
for i in range(0, len(ll)):
    print(str(i) + ": " + str(ll[i]))

print("Explicitly updating an element")
ll[3]=1000;
print(ll)

print("Reversing the list")
ll.reverse()
print(ll)

print("Deleting element 2")
ll.remove(2)
print(ll)

print("Deleting element 20")
ll.remove(20)
print(ll)

print("Checking if list contains element 1000:", 1000 in ll)
