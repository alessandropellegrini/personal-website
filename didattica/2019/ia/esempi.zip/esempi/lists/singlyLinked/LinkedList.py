from collections.abc import MutableSequence
from ListNode import ListNode

class SinglyLinkedList(MutableSequence):
        def __init__(self):
            self.head = None
            self.tail = None

        def insert(self, index, element):
            count = 0
            current_node = self.head
            previous_node = None
            node = ListNode(element)

            while current_node is not None and count < index:
                previous_node = current_node
                current_node = current_node.next
                count += 1

            if count < index - 1:
                raise IndexError('Index ' + str(index) + ' does not fit in list')

            if previous_node is None:
                self.head = node
            else:
                previous_node.next = node

            if current_node is None:
                self.tail.next = node
                self.tail = node
            else:
                node.next = current_node

        def append(self, element):
            node = ListNode(element)
            if self.head is None:
                    self.head = node
            else:
                self.tail.next = node
            self.tail = node

        def appendLeft(self, element):
            node = ListNode(element)
            if self.tail is None:
                self.tail = node
            node.next = self.head
            self.head = node

        def _getitem(self, index):
            count = 0
            current_node = self.head
            while current_node is not None and count < index:
                current_node = current_node.next
                count += 1

            if current_node is None and count != index:
                return None
            return current_node

        def __getitem__(self, index):
            node = self._getitem(index)
            if node is None:
                print('No element at index', index)
                raise IndexError('No element at index', index)
            return self._getitem(index).data

        def __setitem__(self, index, value):
            node = self._getitem(index)
            node.data = value

        def __delitem__(self, index):
            if index == 0:
                self.head = self.head.next
                return

            previous = self._getitem(index - 1)
            if previous is None:
                return

            if previous.next == self.tail:
                self.tail = previous
                self.tail.next = None
                return

            previous.next = previous.next.next


        def __len__(self):
                count = 0
                current_node = self.head
                
                while current_node is not None:
                    count = count + 1
                    current_node = current_node.next
                        
                return count

        def __str__(self):
                current_node = self.head
                dump = "["
                
                while current_node is not None:
                    dump += str(current_node) + ","
                    current_node = current_node.next

                dump += "]"
                return dump
