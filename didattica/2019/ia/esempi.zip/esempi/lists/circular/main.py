#!/usr/bin/env python3
from LinkedList import CircularList

print("Instantiating a Circular Linked List")
ll = CircularList()
print(ll)

print("Adding A, B, C to head")
ll.add("A")
ll.add("B")
ll.add("C")
print(ll)

print("Adding element D and getting reference")
d = ll.add("D")
print(ll)

print("Adding E after D and getting reference")
e = ll.addAfter("E", d)
print(ll)

print("Explicit iterationi starting from E:")
el = next(e)
while el != e:
    print(el, end='')
    el = next(el)

print("")
print("Check if list contains D:", "D" in ll)
print("Check if list contains Z:", "Z" in ll)

print("Deleting element B")
ll.discard("B")
print(ll)
