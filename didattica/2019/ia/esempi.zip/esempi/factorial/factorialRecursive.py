#!/usr/bin/env python3

import sys

def fact(n):
    if n == 0:
        return 1
    else:
        return n * fact(n - 1)

print(fact(int(sys.argv[1])))
