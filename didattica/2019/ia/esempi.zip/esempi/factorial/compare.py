#!/usr/bin/env python3

import sys
import timeit
from memory_profiler import memory_usage
from statistics import mean

def factRecursive(n):
    if n == 0:
        return 1
    else:
        return n * factRecursive(n - 1)

def factIterative(n):
    f = 1
    for i in range(1,n+1):
        f = f * i
    return f

num = sys.argv[1]

# Measure memory consumption
recMem = mean(memory_usage((factRecursive, (int(num),))))
iterMem = mean(memory_usage((factIterative, (int(num),))))

# Measure execution time
recTime = timeit.repeat(setup = "from __main__ import factRecursive", stmt = f"factRecursive({num})", repeat = 3, number = 10000) 
iterTime = timeit.repeat(setup = "from __main__ import factIterative", stmt = f"factIterative({num})", repeat = 3, number = 10000)

print('Recursive factorial time: {}'.format(min(recTime)))  
print('Iterative factorial time: {}'.format(min(iterTime)))  

print('Recursive factorial memory: ', recMem, 'MB')
print('Iterative factorial memory: ', iterMem, 'MB')
