#!/usr/bin/env python3

import sys

def fact(n):
    f = 1
    for i in range(1,n+1):
        f = f * i
    return f

print(fact(int(sys.argv[1])))
