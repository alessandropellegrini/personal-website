#/bin/bash

function evaluate {
	unlink soluzione.csv
	time=$(timeout 20m /usr/bin/time -f "%e" $1 3>&1 1>&2 2>&3 3>&-)
	retval=$?
	./verify.py soluzione.csv
	correct=$?
	if [ $retval -eq 124 ]; then
		echo "TIMEOUT"
		echo -n "Timeout;" >> risultati.csv
	elif [ $correct -ne 0 ]; then 
		echo "Wrong solution"
		echo -n "Soluzione errata;" >> risultati.csv
	elif [ $retval -eq 0 ]; then
		echo "Completed in $time seconds"
		echo -n "$time;" >> risultati.csv
        else
		echo "Errored"
		echo -n "Errored;" >> risultati.csv
	fi
}

echo "" > risultati.csv

for d in */; do
	matricola=$(grep -r "Matricola" $d | sed 's/.*://')
	echo -e "\n*** $matricola ($d) ***"

	echo -n "$matricola;" >> risultati.csv

	echo "Evaluating input 1"
	evaluate "$d/main.py input1.csv"

	echo "Evaluating input 2"
	evaluate "$d/main.py input2.csv"

	echo "Evaluating input 3"
	evaluate "$d/main.py input3.csv"

	echo "Evaluating input 4"
	evaluate "$d/main.py input4.csv"

	echo "" >> risultati.csv
done
