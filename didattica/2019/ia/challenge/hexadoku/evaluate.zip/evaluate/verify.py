#!/usr/bin/env python3

import sys
import csv

class Hexadoku:
        def __init__(self, grid):
                self.grid = grid
                self.numbers = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}
                self.region = [None] * 16
                self.empty = sum(row.count('') for row in self.grid)

        def dups(self, arr):
                arr = [x for x in arr if type(x)==int]
                return len(arr) != len(set(arr))

        def linearRegion(self, r, c):
                r = r // 4 * 4
                c = c // 4 * 4
                for k in range(0,16):
                    self.region[k] = self.grid[r + k // 4][c + k % 4]
        
        def verify(self):
                if self.empty > 0: return False
                for i in range(0, 16):
                    if self.dups(self.grid[i]) or self.dups([row[i] for row in self.grid]): return False
                for i in range(0, 4):
                    for j in range(0, 4):
                        self.linearRegion(i*4, j*4)
                        if self.dups(self.region): return False
                return True
        
if len(sys.argv) != 2:
        print("Utilizzo:", sys.argv[0], "<griglia input>")
        quit()

# load the problem
reader = csv.reader(open(sys.argv[1], "r"), delimiter=",")

s = Hexadoku(list(reader))
assert (s.verify())
