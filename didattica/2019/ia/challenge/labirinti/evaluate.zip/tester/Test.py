#!/usr/bin/env python3

import pickle, sys
import copy
from Labirinto import Labirinto

class Input:
    def __init__(self, grid, start, end):
        self.grid = grid
        self.start = start
        self.end = end

with open(sys.argv[1], 'rb') as fp:
    npt = pickle.load(fp)

l = Labirinto(copy.deepcopy(npt.grid), npt.start, npt.end)
moves = l.solve()

print("Start at", npt.start)
print("end at", npt.end)

print(len(moves))

pos = list(npt.start)

for m in moves:
        if m == 'N':
                if pos[0] == 0 or npt.grid[pos[0] - 1][pos[1]] == 0:
                        print("break 1")
                        break
                pos[0] -= 1
        if m == 'S':
                if pos[0] == len(npt.grid) - 1 or npt.grid[pos[0] + 1][pos[1]] == 0:
                        print("break 2", pos, len(npt.grid) - 1, npt.grid[pos[0] + 1][pos[1]])
                        break
                pos[0] += 1
        if m == 'E':
                if pos[1] == len(npt.grid[0]) - 1 or npt.grid[pos[0]][pos[1] + 1] == 0:
                        print("break 3")
                        break
                pos[1] += 1
        if m == 'W':
                if pos[1] == 0 or npt.grid[pos[0]][pos[1] - 1] == 0:
                        print("break 4")
                        break
                pos[1] -= 1

        l.grid[pos[0]][pos[1]] = 'x'

print(l)
print("pos is", pos)
print(moves)

assert(pos == list(npt.end))
