#/bin/bash

function evaluate {
	time=$(timeout 5s /usr/bin/time -f "%e" $1 3>&1 1>&2 2>&3 3>&-)
	retval=$?
	if [ $retval -eq 124 ]; then
		echo "TIMEOUT"
		echo -n "Timeout;" >> risultati.csv
	elif [ $retval -eq 0 ]; then
		echo "Completed in $time seconds"
		echo -n "$time;" >> risultati.csv
        else
		echo "Errored"
		echo -n "Errored;" >> risultati.csv
	fi
}

echo "" > risultati.csv

export OLDPYTHONPATH=$PYTHONPATH

for d in */; do
	matricola=$(grep -r "Matricola" $d | sed 's/.*://')
	echo -e "\n*** $matricola ($d) ***"

	echo -n "$matricola;" >> risultati.csv
	export PYTHONPATH=$OLDPYTHONPATH:${d%/}
	evaluate "./Test.py 00.maz"
	evaluate "./Test.py 01.maz"
	evaluate "./Test.py 02.maz"
	evaluate "./Test.py 03.maz"
	evaluate "./Test.py 04.maz"
	evaluate "./Test.py 05.maz"
	evaluate "./Test.py 06.maz"
	evaluate "./Test.py 07.maz"
	evaluate "./Test.py 08.maz"

	echo "" >> risultati.csv
done

export PYTHONPATH=$OLDPYTHONPATH
