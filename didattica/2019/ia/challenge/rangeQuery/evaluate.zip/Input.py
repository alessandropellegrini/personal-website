#!/usr/bin/env python3

class Input:
    def __init__(self, x1, x2, y1, y2):
        if x2 < x1:
            x1, x2 = x2, x1
        if y2 < y1:
            y1, y2 = y2, y1

        self.x = [x1, x2]
        self.y = [y1, y2]
        self.num = 0
        self.inRange = 0
        self.points = []

    def addPoint(self, x, y):
        if self.x[0] <= x <= self.x[1] and self.y[0] <= y <= self.y[1]:
            self.inRange += 1
        self.points.append([x, y])

    def __str__(self):
        return str(self.inRange/self.num) + "%"
