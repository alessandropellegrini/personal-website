#!/usr/bin/env python3

import pickle
import sys
from Input import Input

_temp = __import__(sys.argv[1] + ".piano", globals(), locals(), ['PianoCartesiano'], 0)
PianoCartesiano = _temp.PianoCartesiano

with open("a.dataset", 'rb') as fp:
    a = pickle.load(fp)
with open("b.dataset", 'rb') as fp:
    b = pickle.load(fp)
with open("c.dataset", 'rb') as fp:
    c = pickle.load(fp)
with open("d.dataset", 'rb') as fp:
    d = pickle.load(fp)
with open("e.dataset", 'rb') as fp:
    e = pickle.load(fp)
with open("f.dataset", 'rb') as fp:
    f = pickle.load(fp)

plane = PianoCartesiano()

for dataset in [a, b, c, d, e, f]:
    for point in dataset.points:
        plane.addPoint(point[0], point[1])
    print('testing in', dataset.x[0], dataset.x[1], dataset.y[0], dataset.y[1])
    assert(dataset.inRange == plane.query2D(dataset.x[0], dataset.x[1], dataset.y[0], dataset.y[1]))

assert(126000 == plane.query2D(-2000, 2000, -1500, 1000))
