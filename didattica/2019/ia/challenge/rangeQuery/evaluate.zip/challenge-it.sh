#/bin/bash

function evaluate {
	time=$(timeout 20m /usr/bin/time -f "%e" $1 3>&1 1>&2 2>&3 3>&-)
	retval=$?
	if [ $retval -eq 124 ]; then
		echo "TIMEOUT"
		echo -n "Timeout;" >> risultati.csv
	elif [ $retval -eq 0 ]; then
		echo "Completed in $time seconds"
		echo -n "$time;" >> risultati.csv
        else
		echo "Errored"
		echo -n "Errored;" >> risultati.csv
	fi
}

echo "" > risultati.csv

for d in */; do
	matricola=$(grep -r "Matricola" $d | sed 's/.*://')
	echo -e "\n*** $matricola ($d) ***"

	echo -n "$matricola;" >> risultati.csv

	evaluate "./TestDataStructure.py ${d%/}"

	echo "" >> risultati.csv
done
