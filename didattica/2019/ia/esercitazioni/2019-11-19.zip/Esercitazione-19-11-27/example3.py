from  model import SimulationModel
import sys


class Scheduler:
	def __init__(self):
		self.jobs = []
		self.last_used_index = 0
		self.job_list_len = 0
	# sort jobs list
	def init_scheduler(self, jobs):
		self.jobs = sorted(jobs, key=lambda x:x[0])
		self.job_list_len = len(self.jobs)

	# get and remove first item of the ordered job list
	def get_next(self):
		if not self.jobs:
			return None 
		#j = self.jobs[0]
		#self.jobs = self.jobs[1:]  <-- THIS CREATE A FULL COPY!!!!
		j = self.jobs[self.last_used_index]
		self.last_used_index+=1		# removal is logical!! just move the index ahead!!!
		if float(self.last_used_index)/self.job_list_len > 0.10: # when deleted entry reach a given threadshold compact the sorted list!
			self.jobs = self.jobs[self.last_used_index:]
			self.last_used_index = 0
			self.job_list_len = len(self.jobs)
		return j


	# perform SUB-linear search for new job positioning
	def search_job(self, cur):
		low = self.last_used_index
		high = len(self.jobs)-1
		idx = (high+low)/2
		
		while low < high:
			idx = (high+low)//2
			if self.jobs[idx][0] > cur[0]:
				high = idx
			else:
				low  = idx+1
		return low	

	# add new job to the pending list
	def put_job(self, cur):
		self.jobs.insert(self.search_job(cur), cur)


if __name__ == "__main__":
	# possible command lines
	# python example#.py 
	# python example#.py <initial batch size>
	# python example#.py <initial batch size> <number of events>

	# init simulation
	sim_obj = SimulationModel()
	if len(sys.argv) == 1:
		jobs = sim_obj.init_model()
	elif len(sys.argv) == 2:
		jobs = sim_obj.init_model(int(sys.argv[1]))
	elif len(sys.argv) == 3:
		jobs = sim_obj.init_model(int(sys.argv[1]), int(sys.argv[2]))


	# init scheduler
	sched_obj = Scheduler()
	sched_obj.init_scheduler(jobs)


	# run simulation until ending condition is reached
	while True:
		# ask to the scheduler the next job to be run
		j = sched_obj.get_next()
		# run the job and get a new pending job
		cur = sim_obj.schedule_job_and_get_next(j)
		# is the simulation ended?
		if not cur: break
		# add the new job to the scheduler pending list
		sched_obj.put_job(cur)

	# simulation ended --- print statistics
	sim_obj.print_stats()
