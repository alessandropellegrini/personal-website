from  model import SimulationModel
import sys
import heapq


class Scheduler:
	def __init__(self):
		self.jobs = [] # this will be an heap
		self.min_job = None
	# sort jobs list
	def init_scheduler(self, jobs):
		self.jobs = jobs
		heapq.heapify(self.jobs)
		self.min_job = heapq.heappop(jobs) 

	# get and remove first item of the ordered job list
	def get_next(self):
		if not self.min_job:
			return None
		j = self.min_job
		self.min_job = None
		return j

	# add new job to the pending list
	def put_job(self, cur):
		self.min_job = heapq.heappushpop(self.jobs,cur) # just use a pushpop from heap! slightly faster than two separate push and pop

if __name__ == "__main__":
	# possible command lines
	# python example#.py 
	# python example#.py <initial batch size>
	# python example#.py <initial batch size> <number of events>

	# init simulation
	sim_obj = SimulationModel()
	if len(sys.argv) == 1:
		jobs = sim_obj.init_model()
	elif len(sys.argv) == 2:
		jobs = sim_obj.init_model(int(sys.argv[1]))
	elif len(sys.argv) == 3:
		jobs = sim_obj.init_model(int(sys.argv[1]), int(sys.argv[2]))


	# init scheduler
	sched_obj = Scheduler()
	sched_obj.init_scheduler(jobs)


	# run simulation until ending condition is reached
	while True:
		# ask to the scheduler the next job to be run
		j = sched_obj.get_next()
		# run the job and get a new pending job
		cur = sim_obj.schedule_job_and_get_next(j)
		# is the simulation ended?
		if not cur: break
		# add the new job to the scheduler pending list
		sched_obj.put_job(cur)

	# simulation ended --- print statistics
	sim_obj.print_stats()
