This package contains Python scripts to implement a very small simulation of an application 
that creates jobs and asks to a scheduler what job should be dispatched next.

The model can be seen as follows.

   _________________                        _________________
  |                 |      post a new job  |                 |
  |   APPLICATION   |--------------------->| Scheduler (SJF) |
  |_________________|                      |_________________|                        
           ^                                        |
           |                                        |
           |                                        |
           |----------------------------------------|
                       job to be executed  

Here the package organization:
---- Ex1
      |
      |----- model.py <-- this is the code simulating the application
      |----- example1.py <---|
      |----- example2.py <---|
      |----- example3.py <---|--- These files implements both simulation loop and scheduler. Each file implements the SJF policy in  
      |----- example4.py <---|    different ways and using different underlying data structures.
      |----- example5.py <---|
      |----- README.txt <-- this readme

To execute run the following command:
	python example<version>.py <num_of_initial_jobs> <num_of_iterations>
	where <num_of_initial_jobs> it the number of initially pending jobs and <num_of_iterations> controls how many schedule decision are taken during a simulation
Example:
	python example1.py 5000 100000  (this takes about 30s)

Output example:
 _______________________________________________________________________________
|   Jobs Uniformly distributed in:  1us:1023us                                  |  <-- Minimum and maximum job length
|   Starting batch: 5000                                                        |  <-- Initial length of pending-jobs list (num_of_initial_jobs)
|   Simulation events:      100000                                              |  <-- Number of jobs to be executed before ending the simulation (num_of_iterations)
|                                                                               | 
|   Initializing first batch... Done                                            | 
|   Initializing simulation... Done                                             | 
|   Simulation started...                                                       | 
|                                                                               | 
|   First job termination time:     2ms                                         |  <-- This is equal to execution_time_of_first_job + waiting_time_of_first_job 
|   First job start latency:        2ms (99% Overhead)                          |  <-- Overhead for scheduling the first job (lower the better)
|   Ending Simulation time:         60737ms                                     |  <-- Ending time of the simulation in the simulated time
|   Busy time:                      48638ms (80%)                               |  <-- Simulation Time devoted to the execution of jobs 
|   Decisions time:                 12099ms (20% Overhead) (120us per decision) |  <-- Simulation (and Wall-clock) Time spent in the Scheduler module
|   Average Overhead:               25.23%                                      |  <-- Mean Overhead 
|   Min Overhead:                   7.54%                                       |  <-- Minimum Overhead
|   Max Overhead:                   99.90%                                      |  <-- Maximum Overhead
|   Wall-Clock Time:                12.53s                                      |  <-- Wall-clock time taken by the simulation
|   Speed-up over real execution:   4.85x                                       |  <-- Ratio between the Simulation Time and Wall-clock time
|_______________________________________________________________________________| 



