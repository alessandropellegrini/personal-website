from random import seed
from random import randint
from timeit import default_timer as timer

microseconds = 1000000


#########################################################
#		SIMULATION MODEL
#########################################################
#
# This class implements a simulation model of an application that creates jobs and asks to a scheduler to
# execute them by adopting a Shortest Job First (SJF) policy.
# Jobs have variable length according to their class.
# There are 1024 classes such that a job of class i requires i microseconds of CPU to be completed.
#



class SimulationModel:
	def __init__(self):
		self.start_time_simulation=0		# Wall-clock (WC) time of simulation beginning
		self.end_time_simulation=0			# WC time of simulation ending
		self.starting_time_interval=0		# Starting WC time of an interval 
		self.ending_time_interval=0			# Ending WC time of an interval
		self.gvt=0							# Global Virtual Time of the simulation
		self.max_value = (2**10) -1			# max job length in microseconds
		self.min_value = 2**0				# min job length in microseconds
		self.starting_len = 0				# starting batch length
		self.pending_len = 2000				# number of events to process
		self.current_job_id = 0				# current job id 
		self.schedule_count = 0				# jobs count
		self.job_list = []					# list of initial jobs
		self.current_latency = 0			# current latency
		self.accumulator_latency = 0		# time spent while running the scheduler
		self.execution_time = 0				# (virtual) time spent while executing jobs
		self.total_overhead = 0				# total overhead
		self.mino = 2						# min overhead
		self.maxo = 0						# max overhead


	# get the starting time of an interval
	# if required save the starting WC time of the simulation
	def get_start_timer(self):
		tmp = timer()
		if self.start_time_simulation == 0: 				
			self.start_time_simulation = tmp				
		self.starting_time_interval = tmp*microseconds

	# end the current interval and return its length in microseconds
	def get_interval(self):
		tmp = timer()
		self.ending_time_interval = tmp*microseconds
		tmp = self.ending_time_interval - self.starting_time_interval
		return tmp

	# init the simulation model
	def init_model(self, init_size=1000, events=1000):
		# seed for the random number generator
		seed(17)
		print "Jobs Uniformly distributed in:\t" +  str(self.min_value)+"us:"+str(self.max_value)+"us"

		# configure simulation variables
		self.starting_len = init_size
		self.pending_len = events

		print "Starting batch:\t"+str(self.starting_len)
		print "Simulation events:\t"+str(self.pending_len)

		print
		print "Initializing first batch...",

		# generate a list of random jobs
		job_list = []
		for _ in range(self.starting_len):
			j = randint(self.min_value, self.max_value)
			job_list += [(j, self.current_job_id)]  # a job is a pair (<job duration>, <job id>) 
			self.current_job_id += 1

		print "Done"
		print "Initializing simulation...",


		print "Done"

		print "Simulation started..."

		# start simulation and first measurement interval
		self.get_start_timer()
		return job_list


	# this routine execute a job (the one passed as parameter)
	# and returns a new job for the scheduler
	def schedule_job_and_get_next(self, job):

		current_latency = self.get_interval() # in us
		self.gvt += current_latency + job[0]
		self.execution_time += job[0]
		if self.schedule_count == 0:
			print
			print "First job termination time:\t"+str(int((self.execution_time+current_latency)/1000))+"ms "
			print "First job start latency:\t"+str(int((current_latency)/1000))+"ms " +"("+str(int(current_latency*100/(current_latency+self.execution_time)))+"% Overhead)"
		else:
			current_latency =  current_latency
			self.accumulator_latency += current_latency
			ov = float(current_latency)	/(current_latency+ job[0])
			self.mino = min(ov, self.mino)
			self.maxo = max(ov, self.maxo)
			self.total_overhead += ov

		if self.schedule_count == self.pending_len:
			self.end_time_simulation = timer()
			return None

		item = (randint(self.min_value, self.max_value), self.current_job_id)
		self.current_job_id += 1
		self.schedule_count += 1

		self.get_start_timer()
		return item


	def print_stats(self):
		wc_time = self.end_time_simulation-self.start_time_simulation
		accumulator_latency = self.accumulator_latency
		execution_time = self.execution_time
		sim_time = self.accumulator_latency+execution_time
		pending_len = self.pending_len
		total_overhead = self.total_overhead
		sim_time/=1000000
		utilization = int(execution_time*100/(accumulator_latency+execution_time))

		print "Ending Simulation time:\t\t" +str(int((accumulator_latency+execution_time)/1000))+"ms "
		print "Busy time:\t\t\t" +str(int((execution_time)/1000))+"ms ("+str(utilization)+"%)"
		print "Decisions time:\t\t\t" +str(int((accumulator_latency)/1000))+"ms ("+str(100-utilization)+"% Overhead)"+" ("+str(int(accumulator_latency/pending_len))+"us per decision)"
		print("Average Overhead:\t\t%.2f%%" % (total_overhead*100/self.schedule_count))
		print("Min Overhead:\t\t\t%.2f%%" % (self.mino*100))
		print("Max Overhead:\t\t\t%.2f%%" % (self.maxo*100))
		print("Wall-Clock Time:\t\t%.2fs" % (wc_time))
		print("Speed-up over real execution:\t%.2fx" % (sim_time/wc_time))

