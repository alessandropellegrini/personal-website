#!/usr/bin/env python2

import scipy as sp
import matplotlib
matplotlib.use('TKAgg') # Change this as desired.
import gobject
from pylab import *

from matplotlib import animation

# Declare some variables:

dx=0.01        # Interval size in x-direction.
dy=0.01        # Interval size in y-direction.
a=0.5          # Diffusion constant.
timesteps=500  # Number of time-steps to evolve system.

nx = int(1/dx)
ny = int(1/dy)

epsilon = 0.000001

dx2=dx**2 # To save CPU cycles, we'll compute Delta x^2
dy2=dy**2 # and Delta y^2 only once and store them.

# For stability, this is the largest interval possible
# for the size of the time-step:
dt = dx2*dy2/( 2*a*(dx2+dy2) )

# Start u and ui off as zero matrices:
ui = sp.zeros([nx,ny])
u = sp.zeros([nx,ny])

# Now, set the initial conditions (ui).
for i in range(nx):
	for j in range(ny):
		if ( ( (i*dx-0.5)**2+(j*dy-0.5)**2 <= 0.1)
			& ((i*dx-0.5)**2+(j*dy-0.5)**2>=.05) ):
				ui[i,j] = 1

def evolve_ts(u, ui):
	u[1:-1, 1:-1] = ui[1:-1, 1:-1] + a*dt*( (ui[2:, 1:-1] - 2*ui[1:-1, 1:-1] + ui[:-2, 1:-1])/dx2 + (ui[1:-1, 2:] - 2*ui[1:-1, 1:-1] + ui[1:-1, :-2])/dy2 )

def updatefig(frame, *args):
	global u, ui
	im.set_array(ui)
	u[1:-1, 1:-1] = ui[1:-1, 1:-1] + a*dt*(
		(ui[2:, 1:-1] - 2*ui[1:-1, 1:-1] + ui[:-2, 1:-1])/dx2
		+ (ui[1:-1, 2:] - 2*ui[1:-1, 1:-1] + ui[1:-1, :-2])/dy2 )
	ui = sp.copy(u)
	print "Computing and rendering frame", frame[0]
        return u

fig = plt.figure(1)
img = plt.subplot(111)

im = img.imshow(ui, cmap=get_cmap("hot"), interpolation='nearest', origin='lower')
im.figure = fig
fig.colorbar(im)

def run(*args):
    return updatefig(args)

anim = animation.FuncAnimation(fig, run, frames=timesteps, fargs=(im,), interval=1, blit=False, repeat=False)
plt.show()

