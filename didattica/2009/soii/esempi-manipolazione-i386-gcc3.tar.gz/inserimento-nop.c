#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <elf.h>

#define NOP_NUM 10
#define NOP_CODE 0x90 // 1 byte
#define SEC_NUM 1

int main(int argc, char **argv) {

	int elf_src, elf_dst, file_size, i;
	char *src_image, *dst_image;
	Elf32_Ehdr *ehdr_src;
	Elf32_Shdr *shdr_src, *shdr_dst;

	if((elf_src = open(argv[1], O_RDONLY)) == -1) exit(-1);
	if((elf_dst = creat(argv[2], 0644)) == -1) exit(-1);
	file_size = lseek(elf_src, 0L, SEEK_END);
	lseek(elf_src, 0L, SEEK_SET);

	// Prepara lo spazio per le immagini degli ELF in memoria
	src_image = malloc(file_size);
	dst_image = malloc(file_size + NOP_NUM);
	read(elf_src, src_image, file_size);
	
	// Mantiene i riferimenti all'ELF Header sorgente e ai Section Header sorgente/destinazione
	ehdr_src = (Elf32_Ehdr *)src_image;
	shdr_src = (Elf32_Shdr *)(src_image + ehdr_src->e_shoff);

	shdr_dst = (Elf32_Shdr *)(dst_image + ehdr_src->e_shoff + NOP_NUM);

	// Copia l'ELF Header
	memcpy(dst_image, src_image, sizeof(Elf32_Ehdr));

	// Trasla la tabella degli Header di sezione di NOP_NUM byte
	((Elf32_Ehdr *)dst_image)->e_shoff += NOP_NUM;

	// Copia il contenuto di tutte le sezioni, fino a quella in cui inserire le nop
	for(i = 0; i <= SEC_NUM; i++)a
		memcpy(dst_image + shdr_src[i].sh_offset, src_image + shdr_src[i].sh_offset, shdr_src[i].sh_size);
	
	// Inserisce le nop
	memset(dst_image + shdr_src[SEC_NUM].sh_offset + shdr_src[SEC_NUM].sh_size, NOP_CODE, NOP_NUM);

	// Copia le altre sezioni
	for(i = SEC_NUM + 1; i < ehdr_src->e_shnum; i++)
		memcpy(dst_image + shdr_src[i].sh_offset + NOP_NUM, src_image + shdr_src[i].sh_offset, shdr_src[i].sh_size);

	// Copia gli header di tutte le sezioni, fino a quella in cui ha inserito le nop
	for(i = 0; i <= SEC_NUM; i++)
		memcpy(shdr_dst + i, shdr_src + i, sizeof(Elf32_Shdr));

	// Aumenta la dimensione della sezione ingrandita di NOP_NUM byte
	shdr_dst[SEC_NUM].sh_size += NOP_NUM;
	
	// Copia gli header delle altre sezioni e trasla l'offset di NOP_NUM byte
	for(i = SEC_NUM + 1; i < ehdr_src->e_shnum; i++) {
		memcpy(shdr_dst + i, shdr_src + i, sizeof(Elf32_Shdr));
		shdr_dst[i].sh_offset += NOP_NUM;
	}

	write(elf_dst, dst_image, file_size + NOP_NUM);
	close(elf_src);
	close(elf_dst);
}

