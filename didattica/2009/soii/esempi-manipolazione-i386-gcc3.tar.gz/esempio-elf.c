#include <stdio.h>

int xx, yy;

int main(void) {

	xx = 1;
	yy = 2;
	printf("xx %d yy %d\n", xx, yy);
}

