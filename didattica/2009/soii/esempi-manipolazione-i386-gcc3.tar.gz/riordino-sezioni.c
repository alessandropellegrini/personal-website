#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <elf.h>

int main(int argc, char **argv) {

	int elf_src, elf_dst, file_size, i;
	char *src_image, *dst_image, *ptr;
	Elf32_Ehdr *ehdr_src, *ehdr_dst;
	Elf32_Shdr *shdr_src, *shdr_dst;

	// Prepara lo spazio in memoria per i file ELF
	if((elf_src = open(argv[1], O_RDONLY)) == -1) exit(-1);
	if((elf_dst = creat(argv[2], 0644)) == -1) exit(-1);
	file_size = lseek(elf_src, 0L, SEEK_END);
	lseek(elf_src, 0L, SEEK_SET);
	src_image = malloc(file_size);
	ptr = dst_image = malloc(file_size);
	read(elf_src, src_image, file_size);
	ehdr_src = (Elf32_Ehdr *)src_image;
	ehdr_dst = (Elf32_Ehdr *)dst_image;

	// Copia l'ELF Header
	memcpy(ptr, src_image, sizeof(Elf32_Ehdr)); 
	ptr += sizeof(Elf32_Ehdr);

	// Prepara lo spazio per gli header delle sezioni
	shdr_dst = (Elf32_Shdr *)ptr;
	shdr_src = (Elf32_Shdr *)(src_image + ehdr_src->e_shoff);
	ehdr_dst->e_shoff = sizeof(Elf32_Ehdr);
	ptr += ehdr_src->e_shnum * ehdr_dst->e_shentsize;

	// La sezione nulla deve essere sempre in testa ed ha dimensione nulla
	memcpy(shdr_dst, shdr_src, sizeof(Elf32_Shdr));

	// Copia le sezioni invertendone l'ordine
	for(i = ehdr_src->e_shnum - 1; i > 0; i--) {

		// Copia le sezioni e gli header
		memcpy(shdr_dst + ehdr_src->e_shnum - i, shdr_src + i, sizeof(Elf32_Shdr)); 
		memcpy(ptr, src_image + shdr_src[i].sh_offset, shdr_src[i].sh_size); 
		shdr_dst[ehdr_src->e_shnum - i].sh_offset = ptr - dst_image;

		// Corregge i riferimenti tra sezioni
		if(shdr_src[i].sh_link > 0)
			shdr_dst[ehdr_src->e_shnum - i].sh_link = ehdr_src->e_shnum - shdr_src[i].sh_link;

		if(shdr_src[i].sh_info > 0)
			shdr_dst[ehdr_src->e_shnum - i].sh_info = ehdr_src->e_shnum - shdr_src[i].sh_info;

		ptr += shdr_src[i].sh_size;
	}

	// Corregge il riferimento alla tabella delle stringhe
	ehdr_dst->e_shstrndx = ehdr_src->e_shnum - ehdr_src->e_shstrndx;

	write(elf_dst, dst_image, file_size);
	close(elf_src);
	close(elf_dst);
}

