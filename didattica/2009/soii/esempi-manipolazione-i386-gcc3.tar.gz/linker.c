#include <stdio.h>

int xx = 1;
int yy;

int main(void) {

	printf("&xx: %#lx &yy: %#lx\n", (unsigned long)&xx, (unsigned long)&yy);

	return 0;
}

